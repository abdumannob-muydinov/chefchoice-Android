package com.example.chefchoice;

import android.os.Parcel;
import android.os.Parcelable;

class credentialDetail implements Parcelable {
    private int sec_id ;
    private String name, password;

    public credentialDetail(int sec_id, String name, String password) {
        this.sec_id = sec_id;
        this.name = name;
        this.password = password;
    }

    public int getSec_id() {
        return sec_id;
    }

    public void setSec_id(int sec_id) {
        this.sec_id = sec_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    protected credentialDetail(Parcel in) {
        sec_id = in.readInt();
        name = in.readString();
        password = in.readString();
    }

    public static final Creator<credentialDetail> CREATOR = new Creator<credentialDetail>() {
        @Override
        public com.example.chefchoice.credentialDetail createFromParcel(Parcel in) {
            return new com.example.chefchoice.credentialDetail(in);
        }

        @Override
        public com.example.chefchoice.credentialDetail[] newArray(int size) {
            return new com.example.chefchoice.credentialDetail[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(sec_id);
        dest.writeString(name);
        dest.writeString(password);
    }
}
