package com.example.chefchoice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etUsername , etPassword;
    TextView tvError;

    private IntentFilter TransIntentFilter,CredIntentFilter ;
    private Intent transIntent;
    public ArrayList<com.example.chefchoice.transactionDetails> transactionList;

    boolean flag = false;
    public static int session = -1;
    public static String uname = null;

    public static com.example.chefchoice.DatabaseHelper dbHelper;


    public static     int ImgIds[ ] = { R.drawable.ic_fork,R.drawable.ic_restaurant};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        tvError = findViewById(R.id.tvError);
        tvError.setVisibility(View.INVISIBLE);

        dbHelper = new com.example.chefchoice.DatabaseHelper(this);


        CredIntentFilter  = new IntentFilter();
        CredIntentFilter .addAction("CREDENTIALS_COMING_ACTION");
        registerReceiver(CredIntentReceiver, CredIntentFilter);


        transIntent = new Intent(this, com.example.chefchoice.TransactionsJSONParseIntentService.class);
        startService(transIntent);

        TransIntentFilter = new IntentFilter();
        TransIntentFilter.addAction("TRANSACTIONS_COMING_ACTION");
        registerReceiver(TransIntentReceiver, TransIntentFilter);

    }

    private final BroadcastReceiver TransIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            transactionList = intent.getParcelableArrayListExtra("transaction");


        }
    };
    private final BroadcastReceiver CredIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle b;
            b = intent.getExtras();

            flag  =  b.getBoolean("result");
            if(flag == false){
                tvError.setVisibility(View.VISIBLE);
            }
            else{
                Toast.makeText(com.example.chefchoice.MainActivity.this, "Login Successful" , Toast.LENGTH_LONG).show();
                uname = b.getString("uname");
                session = b.getInt("session_ID");

                Bundle sendB = new Bundle();
                sendB.putString("uname",uname);
                sendB.putInt("session",session);

                insertInTransDB();

                Intent credintent = new Intent(com.example.chefchoice.MainActivity.this, com.example.chefchoice.Dashboard.class);
                credintent.putExtras(sendB);
                startActivity(credintent);
            }
        }
    };

    private void insertInTransDB (){
        for(int i = 0; i< transactionList.size(); i++){
            com.example.chefchoice.transactionDetails td = transactionList.get(i);
            Integer id = td.getId();
            if (TransactionDB.isTransactionExist(dbHelper,id) == false){
                Integer userID = td.getUser_id();
                Integer t_id = td.getT_id();

                String name = td.getName();
                String ing = td.getIngredient();
                String rec = td.getRecipe();

                TransactionDB.insertTransaction(com.example.chefchoice.MainActivity.dbHelper,userID, t_id, name, ing,  rec);
            }
        }

    }

    public void onClick(View view) {
        String username =  etUsername.getText().toString();
        String password =  etPassword.getText().toString();

        Bundle b = new Bundle();
        b.putString("username",username);
        b.putString("password",password);

        Intent intent = new Intent(this, com.example.chefchoice.CredentialsJSONParseIntentService.class);
        intent.putExtras(b);
        startService(intent);

    }
}
