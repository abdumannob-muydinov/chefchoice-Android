package com.example.chefchoice;

import android.os.Parcel;
import android.os.Parcelable;

public class transactionDetails implements Parcelable {

    private int id , t_id, user_id;
    private String name, ingredient, recipe;

    public transactionDetails(int id, int user_id, int t_id, String name, String ingredient, String recipe) {
        this.id = id;
        this.t_id = t_id;
        this.user_id = user_id;
        this.name = name;
        this.ingredient = ingredient;
        this.recipe = recipe;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getT_id() {
        return t_id;
    }

    public void setT_id(int t_id) {
        this.t_id = t_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIngredient() {
        return ingredient;
    }

    public void setIngredient(String ingredient) {
        this.ingredient = ingredient;
    }

    public String getRecipe() {
        return recipe;
    }

    public void setRecipe(String recipe) {
        this.recipe = recipe;
    }

    protected transactionDetails(Parcel in) {
        id = in.readInt();
        user_id = in.readInt();
        t_id = in.readInt();
        name = in.readString();
        ingredient = in.readString();
        recipe = in.readString();
    }

    public static final Creator<transactionDetails> CREATOR = new Creator<transactionDetails>() {
        @Override
        public com.example.chefchoice.transactionDetails createFromParcel(Parcel in) {
            return new com.example.chefchoice.transactionDetails(in);
        }

        @Override
        public com.example.chefchoice.transactionDetails[] newArray(int size) {
            return new com.example.chefchoice.transactionDetails[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(user_id);
        dest.writeInt(t_id);
        dest.writeString(name);
        dest.writeString(ingredient);
        dest.writeString(recipe);
    }
}
