package com.example.chefchoice.extra;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.chefchoice.MainActivity;
import com.example.chefchoice.R;

public class SplashActivity extends AppCompatActivity {

    Intent intent;
    private static int SPLASH_TIME_OUT = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);

        playAudio();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {

                intent = new Intent(SplashActivity.this, MainActivity.class);

                // Close this activity
                finish();

                startActivity(intent);
            }
        }, SPLASH_TIME_OUT);

        YoYo.with(Techniques.FadeIn).duration(2000).repeat(0).playOn(findViewById(R.id.splashConstraint));


    }

    public void playAudio(){
        //set up MediaPlayer
        MediaPlayer mp = MediaPlayer.create(SplashActivity.this, R.raw.sound);
        mp.start();
    }


}
