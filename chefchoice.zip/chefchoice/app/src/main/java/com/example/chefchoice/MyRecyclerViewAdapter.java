package com.example.chefchoice;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyRecyclerViewItemHolder> {
    private Context context;
    private ArrayList<com.example.chefchoice.transactionDetails> recyclerItemValues;
    private RecyclerView recyclerView;
    Dialog customDialog;
    TextView etIngredient1, etName, etRecipe, tvTitle;
    Button btnAdd;
    int checkIndex = 0;


    public MyRecyclerViewAdapter(Context context, ArrayList<com.example.chefchoice.transactionDetails> values, RecyclerView recyclerView, int checkIndex){
        this.context = context;
        this.recyclerItemValues = values;
        this.recyclerView = recyclerView;
        this.checkIndex = checkIndex;
    }

    @NonNull
    @Override
    public MyRecyclerViewItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflator = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflator.inflate(R.layout.recycler_layout, viewGroup, false);
        MyRecyclerViewItemHolder mViewHolder = new MyRecyclerViewItemHolder(itemView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewItemHolder myRecyclerViewItemHolder, int i) {
        if(checkIndex ==1){
            myRecyclerViewItemHolder.imgCurrency.setImageResource(R.drawable.ic_fork);
        }
        else {
            myRecyclerViewItemHolder.imgCurrency.setImageResource(R.drawable.ic_restaurant);
        }

        final int position = i;
        final com.example.chefchoice.transactionDetails td = recyclerItemValues.get(i);

        final String res = "Name: " +td.getName()+
                "\n\nIngredients: " +td.getIngredient()+
                "\n\nRecipe: "+td.getRecipe();

        myRecyclerViewItemHolder.tvName.setText(td.getName());

        myRecyclerViewItemHolder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog = new Dialog(context);
                customDialog.setContentView(R.layout.custom_dialogue_box);
                customDialog.show();

                etName = customDialog.findViewById(R.id.etRname);

                etIngredient1 = customDialog.findViewById(R.id.etIng1);
                etRecipe = customDialog.findViewById(R.id.etRecipe);
                btnAdd = customDialog.findViewById(R.id.btnAdd);
                tvTitle = customDialog.findViewById(R.id.tvTitle);
                btnAdd.setText("Modify");
                tvTitle.setText("Modify Data");

                etName.setText(td.getName());
                etIngredient1.setText(td.getIngredient());
                etRecipe.setText(td.getRecipe());

                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String newName = etName.getText().toString();
                        String newIng = etIngredient1.getText().toString();
                        String newRecipe = etRecipe.getText().toString();

                        TransactionDB.updateTransactions(MainActivity.dbHelper,td.getId(),newName,newIng,newRecipe);

                        td.setName(newName);
                        td.setIngredient(newIng);
                        td.setRecipe(newRecipe);
                        customDialog.dismiss();
                    }
                });
            }
        });

        myRecyclerViewItemHolder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeAndShowDialogBox(res);
            }
        });
    }


    @Override
    public int getItemCount() {
        return recyclerItemValues.size();
    }



    class MyRecyclerViewItemHolder extends  RecyclerView.ViewHolder{
        TextView tvName ;

        ImageView imgCurrency;
        ImageView btnEdit;
        ConstraintLayout parentLayout;
        public MyRecyclerViewItemHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);

            imgCurrency = itemView.findViewById(R.id.imgCurrency);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            parentLayout = itemView.findViewById(R.id.constLayout);
        }
    }


    private void makeAndShowDialogBox(String message) {
        AlertDialog.Builder mDialogBox = new AlertDialog.Builder(context);
        mDialogBox.setTitle("Details");
        mDialogBox.setMessage(message);
        mDialogBox.setPositiveButton("Close",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                });
        mDialogBox.create();
        mDialogBox.show();
    }

}
