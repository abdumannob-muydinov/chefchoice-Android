package com.example.chefchoice;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Lunch extends AppCompatActivity {

    Dialog customDialog;
    Intent recieveIntent, backIntent;
    Bundle rBundle;
    int user_id, t_id;
    public static Double lsize = 0.0;
    List<com.example.chefchoice.transactionDetails> lunchList;
    ImageView imgBackBtn, imgAddBtn;
    TextView etIngredient1, etName, etRecipe, tvTotalValue, tvTitle;
    Button btnAdd;

    private RecyclerView recyclerTransactions;
    LinearLayoutManager layoutManager;
    com.example.chefchoice.MyRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.lunch_layout);
        tvTotalValue = findViewById(R.id.tvTotalValue);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        recieveIntent = getIntent();
        rBundle = recieveIntent.getExtras();
        user_id = rBundle.getInt("user_id");
        t_id = rBundle.getInt("t_id");

        recyclerTransactions = findViewById(R.id.recyclerTransactions);
        imgBackBtn = findViewById(R.id.imgBackBtn);
        imgAddBtn = findViewById(R.id.imgAddBtn);

        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerTransactions.setLayoutManager(layoutManager);
        recyclerTransactions.hasFixedSize();

        lunchList = com.example.chefchoice.TransactionDB.findTransactions(com.example.chefchoice.MainActivity.dbHelper,user_id,t_id);
        Collections.reverse(lunchList);
        adapter = new com.example.chefchoice.MyRecyclerViewAdapter(com.example.chefchoice.Lunch.this, (ArrayList<com.example.chefchoice.transactionDetails>) lunchList, recyclerTransactions,1);
        recyclerTransactions.setAdapter(adapter);

        createDialog();

        imgAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog.show();
            }
        });

        lsize = Double.valueOf(lunchList.size());
        tvTotalValue.setText(""+lsize);
    }

    public void createDialog(){
        customDialog = new Dialog(this);
        customDialog.setContentView(R.layout.custom_dialogue_box);

        etName = customDialog.findViewById(R.id.etRname);
        etIngredient1 = customDialog.findViewById(R.id.etIng1);
        etRecipe = customDialog.findViewById(R.id.etRecipe);
        btnAdd = customDialog.findViewById(R.id.btnAdd);
        tvTitle = customDialog.findViewById(R.id.tvTitle);
        tvTitle.setText("Add Data");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String newName = etName.getText().toString();
                String newIngredient = etIngredient1.getText().toString();
                String newRecipe = etRecipe.getText().toString();

                com.example.chefchoice.transactionDetails newData = com.example.chefchoice.TransactionDB.insertTransaction(com.example.chefchoice.MainActivity.dbHelper,user_id, t_id, newName,  newIngredient, newRecipe);
                lunchList.add(newData);
                adapter = new com.example.chefchoice.MyRecyclerViewAdapter(com.example.chefchoice.Lunch.this, (ArrayList<com.example.chefchoice.transactionDetails>) lunchList, recyclerTransactions,1);
                recyclerTransactions.setAdapter(adapter);
                Collections.reverse(lunchList);


                lsize = Double.valueOf(lunchList.size());
                tvTotalValue.setText(""+lsize);
                etName.setText("");

                etIngredient1.setText("");

                etRecipe.setText("");
                customDialog.dismiss();
            }
        });

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerTransactions);
    }
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                if (direction == ItemTouchHelper.LEFT){

                    lsize = Double.valueOf(lunchList.size());
                    tvTotalValue.setText(""+lsize);
                    com.example.chefchoice.TransactionDB.deleteTransaction(com.example.chefchoice.MainActivity.dbHelper,lunchList.get(position).getId());
                    lunchList.remove(position);
                    adapter.notifyItemRemoved(position);
                }
            }
            @Override
            public int getMovementFlags(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
                int swipeFlags = ItemTouchHelper.LEFT;
                return makeMovementFlags(0,swipeFlags);
            }
        };

    public void onClick(View view) {
        backIntent = new Intent(this, com.example.chefchoice.Dashboard.class);
        Bundle sendB = new Bundle();
        sendB.putString("uname", com.example.chefchoice.MainActivity.uname);
        sendB.putInt("session", com.example.chefchoice.MainActivity.session);
        backIntent.putExtras(sendB);

        startActivity(backIntent);
    }
}
