package com.example.chefchoice;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class TransactionsJSONParseIntentService extends IntentService {
    private String jsonStr;
    private JSONArray transaction;
    private JSONObject transactionJSONObject;

    // ArrayList containing HashMap for RecyclerView
     private ArrayList<com.example.chefchoice.transactionDetails> mArrayList = new ArrayList<>();

    public static final String TAG_TRANSACTIONS = "transactions";
    public static final String TAG_ID = "id";
    public static final String TAG_USER_ID = "user_id";
    public static final String TAG_T_ID = "t_id";

    public static final String TAG_NAME= "name";
    public static final String TAG_INGREDIENT= "ingredient";
    public static final String TAG_RECIPE= "recipe";

    public TransactionsJSONParseIntentService() {
        super("TransactionsJSONParseIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        Log.d("IntentService============================================", "Service Started");
        jsonStr = loadFileFromAssets("transactions.json");
        Log.d("IntentService============================================", jsonStr);
        if (jsonStr != null) {
            try {
                transactionJSONObject = new JSONObject(jsonStr);

                transaction = transactionJSONObject.getJSONArray(TAG_TRANSACTIONS);


                for (int i = 0; i < transaction.length(); i++) {

                    JSONObject c = transaction.getJSONObject(i);

                    Integer Id = c.getInt(TAG_ID);
                    Integer userID = c.getInt(TAG_USER_ID);
                    Integer t_id = c.getInt(TAG_T_ID);
                    String name = c.getString(TAG_NAME);
                    String ingredient = c.getString(TAG_INGREDIENT);
                    String recipe = c.getString(TAG_RECIPE);

                    com.example.chefchoice.transactionDetails transactionType = new com.example.chefchoice.transactionDetails(Id, userID, t_id, name, ingredient, recipe);
                    mArrayList.add(transactionType);
                }

            } catch (JSONException ee) {
                ee.printStackTrace();
            }
        }


        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("TRANSACTIONS_COMING_ACTION");
        broadcastIntent.putParcelableArrayListExtra("transaction",mArrayList);
        sendBroadcast(broadcastIntent);
    }

    private String loadFileFromAssets(String fileName) {
        String fileContent = null;
        try {

            InputStream is = getBaseContext().getAssets().open(fileName);

            int size = is.available();
            byte[] buffer = new byte[size];

            is.read(buffer);
            is.close();

            fileContent = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return fileContent;
    }


}
