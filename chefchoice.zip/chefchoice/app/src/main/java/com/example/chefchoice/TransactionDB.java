package com.example.chefchoice;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class TransactionDB {

    public static final String TABLE_NAME ="transactions";
    public static final String FIELD_ID = "id";
    public static final String FIELD_USERID = "userId";
    public static final String FIELD_TID = "t_id";

    public static final String FIELD_NAME = "name";
    public static final String FIELD_INGREDIENT = "ingredient";
    public static final String FIELD_RECIPE = "recipe";

    public static final String CREATE_TABLE_SQL = "CREATE TABLE "+TABLE_NAME+" ("+FIELD_ID+" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "+FIELD_USERID+" number, "+FIELD_TID+" number, "+FIELD_NAME+" text, "+FIELD_INGREDIENT+" text, "+FIELD_RECIPE+" text);";

    public static final String DROP_TABLE_SQL = "DROP TABLE if exists "+TABLE_NAME;

    public static List<com.example.chefchoice.transactionDetails> findTransactions(com.example.chefchoice.DatabaseHelper db, int user_id, int t_id ){

        String where = FIELD_USERID+" like '%"+user_id+"%' and "+FIELD_TID+" like '%"+t_id+"%'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME,null, where);
        List<com.example.chefchoice.transactionDetails> data = new ArrayList<>();
        com.example.chefchoice.transactionDetails aTrans = null;
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            int uid = cursor.getInt(1);
            int tid = cursor.getInt(2);
            String name = cursor.getString(3);
            String ingredient = cursor.getString(4);
            String recipe = cursor.getString(5);

            aTrans= new com.example.chefchoice.transactionDetails(id,uid, tid, name,  ingredient, recipe);
            data.add(aTrans);
        }
        return data;
    }

    public static int getLastAddedRowId() {
        String queryLastRowInserted = "select last_insert_rowid()";

        final Cursor cursor = com.example.chefchoice.DatabaseHelper.db.rawQuery(queryLastRowInserted, null);
        int _idLastInsertedRow = 0;
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    _idLastInsertedRow = cursor.getInt(0);
                }
            } finally {
                cursor.close();
            }
        }

        return _idLastInsertedRow;

    }

    public static com.example.chefchoice.transactionDetails insertTransaction(com.example.chefchoice.DatabaseHelper db, int user_id, int t_id, String name, String ingredient, String recipe){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_USERID, user_id);
        contentValues.put(FIELD_TID,t_id);

        contentValues.put(FIELD_NAME, name);

        contentValues.put(FIELD_INGREDIENT, ingredient);
        contentValues.put(FIELD_RECIPE,recipe);

        db.insert(TABLE_NAME,contentValues);
        com.example.chefchoice.transactionDetails td = new com.example.chefchoice.transactionDetails(getLastAddedRowId(), user_id, t_id, name, ingredient, recipe);
        return td;
    }
    public static boolean updateTransactions(com.example.chefchoice.DatabaseHelper db, int id, String name, String ingredient, String recipe){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_NAME, name);
        contentValues.put(FIELD_INGREDIENT, ingredient);
        contentValues.put(FIELD_RECIPE, recipe);

        String where = FIELD_ID +" = "+id;

        boolean res = db.update(TABLE_NAME,contentValues,where);

        return res;
    }
    public static boolean isTransactionExist(com.example.chefchoice.DatabaseHelper db, int id){
        String where = FIELD_ID +" = '"+id+"'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME,null, where);
        if(cursor.moveToNext()){
            return true;
        }
        return  false;
    }
    public static boolean deleteTransaction(com.example.chefchoice.DatabaseHelper db, int id){
        String where = FIELD_ID +" = "+ id;
        boolean res = db.delete(TABLE_NAME,where);
        return res;
    }
}
