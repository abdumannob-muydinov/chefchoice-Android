package com.example.chefchoice;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Dashboard extends AppCompatActivity {
    TextView tvWelcome;
    String uname;
    Intent recieveIntent;
    Bundle rBundle;
    int user_id;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        recieveIntent = getIntent();
        rBundle = recieveIntent.getExtras();
        uname = rBundle.getString("uname");
        user_id = rBundle.getInt("session");

        tvWelcome = findViewById(R.id.tvWelcome);
        tvWelcome.setText("Welcome "+uname);
    }


    public void logout(View view) {
        Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, MainActivity.class);
        MainActivity.session =-1;

        startActivity(intent);
    }
}
